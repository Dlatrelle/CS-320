import static org.junit.Assert.*;

import org.junit.Test;

public class AppointmentServiceTest {

	@Test
	public void testNewAppointment() {
		fail("Not yet implemented");
	}

	@Test
	public void testNewAppointmentDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testNewAppointmentDateString() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteAppointment() {
		fail("Not yet implemented");
	}

}
