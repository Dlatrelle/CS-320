	import java.util.Date;
	import java.util.ArrayList;
	import java.util.List;

	public class AppointmentService {

		final private List<Appointment> appointmentList = new ArrayList<>();
		
		public void newAppointment() {
			Appointment appt = new Appointment(newappointmentID());
			appointmentList.add(appt);
		}
		
		public void newAppointment(Date appointmentDate) {
			Appointment appt = new Appointment(newappointmentID(), appointmentDate);
			appointmentList.add(appt);
		}
		
		public void newAppointment(Date appointmentDate, String appointmentDescription) {
			Appointment appt = new Appointment(newappointmentID(), appointmentDate, appointmentDescription);
			appointmentList.add(appt);
		}
		
		public void deleteAppointment(String appointmentID)throws Exception{
			appointmentList.remove(searchforappointment(appointmentID));
		}
		
		private Appointment searchforappointment(String appointmentID)throws Exception{
			int index = 0;
			while (index < appointmentList.size()) {
				if(appointmentID.equals(appointmentList.get(index).getappointmentID())) {
					return appointmentList.get(index);
				}
				index++;
			}
			throw new Exception("Doesn't recognize appointmentAppointmenrt.");
		}
}
