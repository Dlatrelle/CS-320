
public class ContactService {

	
	//Add contact
	public void addContact(String firstName, String lastNamelast name, String phoneNumber, String addressField) {
		contact = new contact(firstName, lastName, phoneNumber, addressField);
		contactListcontact list.add(contact);
	}
	
	//Delete contact
	public void deleteContact(String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getContactID().equalsequals(contactID)) {
				contactList.remove(counter);
				break;
			}
		}
	}
	
	//update contact 
	public void updatefirstName(String updateString, String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getcontactID().equals(contactID)) {
				contactList.get(counter).setfirstName(updatedString);
				break;
			}
		}
	}
	public void updatelastName(String updateString, String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getcontactID().equals(contactID)) {
				contactList.get(counter).setlastName(updatedString);
				break;
			}
		}
	}
	public void updatephoneNumber(String updateString, String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getcontactID().equals(contactID)) {
				contactList.get(counter).setphoneNumber(updatedString);
				break;
			}
		}
	}
	public void updateaddressField(String updateString, String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getcontactID().equals(contactID)) {
				contactList.get(counter).setaddressField(updatedString);
				break;
			}
		}
	}

}
