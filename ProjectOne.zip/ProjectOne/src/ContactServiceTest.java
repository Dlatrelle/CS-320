import static org.junit.Assert.*;

import org.junit.Test;

public class ContactServiceTest {

	@Test
	public void testAddContact() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteContact() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdatefirstName() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdatelastName() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdatephoneNumber() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateaddressField() {
		fail("Not yet implemented");
	}

}
