
public class Task {
	private String taskID;
	private String taskName;
	private String taskDescription;

	public String gettaskID(String taskID) throws Exception {
		if (taskID == null || taskID.length() > 10) {
			throw new Exception("taskID ERROR");
		}
		else {
			this.taskID = taskID;
		}
		return taskID;
	}
	public String gettaskName(String taskName) throws Exception {
		if (taskName == null || taskName.length() > 20) {
			throw new Exception("taskName ERROR");
		}
		else {
			this.taskName = taskName;
		}
		return taskName;
	}
	public String gettaskDescription() throws Exception {
		if (taskDescription == null || taskDescription.length() > 50) {
			throw new Exception("taskDescription ERROR");
		}
		else {
			this.taskDescription = taskDescription;
		}
		return taskDescription;
	}
}
