
public class Contact {
	
		private String contactID;;
		private String firstName;
		private String lastName;
		private String phoneNumber;
		private String addressField;
		
		public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address, String addressField field) throws exception{
		super();
		setcontactID(contactID);
		setfirstName(firstName);
		this.lastName = lastName;
		
		if (phoneNumber == null || phoneNumber.trim().length() < 1 || phoneNumber.matches(".*\\D+.*")) {
			throw new Exception ("phoneNumber ERROR");
		}
			setphoneNumber(phoneNumber);
		this.phoneNumber = phoneNumber;
		this.addressField = addressField;
		
		}
		
		private void setfirstName(String firstName2) {
			// TODO Auto-generated method stub
			
		}

		public String getfirstName() {
			return firstName;
		
		if (firstName == null ||firstName.trim().length() < 1 || firstName.length() > 10) {
			throw new Exception("firstName ERROR");
			}
		

		public String getlastName() {
			return lastName;
		}
		public void setlastName(String lastName) {
			this.lastName = lastName;
		}
		public String getphoneNumber() {
			return phoneNumber;
		}
		public void setphoneNumber(String phoneNumber) {
			if (phoneNumber == null || phoneNumber.trim().length() < 1 || phoneNumber.matches(".*\\D+.*")) {
				throw new Exception ("phoneNumber ERROR");
				
			this.phoneNumber = phoneNumber;}
			}
		public String getaddressField() {
			return addressField;
		}
		public void setaddressField (String addressField) {
			this.addressField = addressField;
		}
		
		public String getcontactID() {
			return contactID;
		}
		
		private void setcontactID(String contactID) {
			if (contactID == null || contactID.trim().length() < 1 || contactID.length() > 10){
				throw new Exception("contactID ERROR");
			}	
			this.contactID = contactID;
		}
}
