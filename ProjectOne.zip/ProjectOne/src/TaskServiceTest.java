import static org.junit.Assert.*;

import org.junit.Test;

public class TaskServiceTest {

	@Test
	public void testNewtask() {
		fail("Not yet implemented");
	}

	@Test
	public void testNewTask() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteTask() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdatetaskName() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdatetaskDescripton() {
		fail("Not yet implemented");
	}

}
