	import java.util.concurrent.atomic.AtomicLong;
	import java.util.Calendar;
	import java.util.Date;

	public class Appointment {

	private String appointmentID;
	private Date appointmentDate;
	private String appointmentDescription;

	public String getappointmentID() {
		return appointmentID;
	}

	public String getappointmentDate() {
		return appointmentDate;
	}

	public String getappointmentDescription() {
		return appointmentDescription;
	}
	if (appointmentDate == null) {
		this.appointmentDate = new Date(2024, Calendar.OCTOBER, 6);
	}
	else if (appointmentDate.before(new Date())){
		throw new IllegalArgumentException("Date not valid.");
	}
	else {
		this.appointmentDate = appointmentDate;
	}
	public void setappointmentDescription(String appointmentDescription){
		if (appointmentDescription == null || appointmentDescription.isEmpty()) {
			this.appointmentDescription = null;
		}
		else if (appointmentDescription.length() > 50) {
			this.appointmentDescription = appointmentDescription.substring(0,50);
		}
		else {
			this.appointmentDescription = appointmentDescription;
		}
	}
	public void setappointmentID(String appointmentID) {
		if (appointmentID == null) {
			throw new IllegalArgumentException("AppointmentID cannot be null");
		}
		else if (appointmentID.length() > 10) {
			throw new IllegalArgumentException("Limit for ApppoinmentID is 10 characters.");
		}
		else {
			this.appointmentID = appointmentID;
		}
	}
	}
}
