import java.awt.List;
import java.util.ArrayList;

public class TaskService {

	private final ArrayList taskList = new ArrayList();
	
	public void newtask(String taskName, String taskDescription) {
		Task taskName = new taskName(taskID(), taskName(), taskDescription());
		taskList.add(taskName);
	}
	public void newTask(String taskName, String taskDescription) {
		String taskName = new taskName(taskName,taskName, taskDescription);
		taskList.add(taskName);
	}
	
	public void deleteTask(String taskID)throws Exception{
		taskList.remove(searchfortask(taskID);
	}
	public void updatetaskName(String taskID, String taskName) thows Exception {
		searchfortask(taskID).settaskName(taskName);
	}
	public void updatetaskDescripton(String taskID, String taskDescription)
	throws Exception{
		searchfortask(taskID).setdescription(taskDescription)
	}
}
