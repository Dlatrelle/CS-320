import static org.junit.Assert.*;

import org.junit.Test;

public class ContactTest {

	@Test
	public void testContact() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetfirstName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetlastName() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetlastName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetphoneNumber() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetphoneNumber() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetaddressField() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetaddressField() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetcontactID() {
		fail("Not yet implemented");
	}

}
